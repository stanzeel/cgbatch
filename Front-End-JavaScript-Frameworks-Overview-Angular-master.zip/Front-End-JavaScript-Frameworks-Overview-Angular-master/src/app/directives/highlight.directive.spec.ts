import {HighlightDirective} from './highlight.directive';

describe('HighlightDirective' , () => {
  it('should create an instance' , () => {
    // @ts-ignore
    const directive = new HighlightDirective();
    expect(directive).toBeTruthy();
  });
});
